import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class RadioButtonDemo extends JFrame implements ActionListener {

    private JRadioButton bird, cat, dog, rabbit, pig;
    private JLabel petImage;

    public RadioButtonDemo() {
        setTitle("RadioButtonDemo");
        setSize(600, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new java.awt.GridLayout(5, 1, 5, 5));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 5));

        bird = new JRadioButton("Bird");
        cat = new JRadioButton("Cat");
        dog = new JRadioButton("Dog");
        rabbit = new JRadioButton("Rabbit");
        pig = new JRadioButton("Pig");

        // ButtonGroup ensures that only one pet can be selected at a time.
        ButtonGroup group = new ButtonGroup();
        group.add(bird);
        group.add(cat);
        group.add(dog);
        group.add(rabbit);
        group.add(pig);

        buttonPanel.add(bird);
        buttonPanel.add(cat);
        buttonPanel.add(dog);
        buttonPanel.add(rabbit);
        buttonPanel.add(pig);

        bird.addActionListener(this);
        cat.addActionListener(this);
        dog.addActionListener(this);
        rabbit.addActionListener(this);
        pig.addActionListener(this);

        petImage = new JLabel("Select a pet", SwingConstants.CENTER);
        petImage.setPreferredSize(new Dimension(380, 280));
        petImage.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 15));

        add(buttonPanel, BorderLayout.WEST);
        add(petImage, BorderLayout.CENTER);

        // Start with Pig selected, matching the example in the assignment.
        pig.setSelected(true);
        displayPet("Pig", "pig.jpg");

        setLocationRelativeTo(null);
    }

    private void displayPet(String petName, String fileName) {
        URL imageUrl = getClass().getResource("/images/" + fileName);
        if (imageUrl == null) {
            petImage.setIcon(null);
            petImage.setText("Image not found: " + fileName);
            return;
        }

        ImageIcon originalIcon = new ImageIcon(imageUrl);
        Image scaledImage = originalIcon.getImage().getScaledInstance(
                360, 260, Image.SCALE_SMOOTH);
        petImage.setText("");
        petImage.setIcon(new ImageIcon(scaledImage));
        petImage.setToolTipText(petName);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String petName;
        String fileName;

        if (bird.isSelected()) {
            petName = "Bird";
            fileName = "bird.jpg";
        } else if (cat.isSelected()) {
            petName = "Cat";
            fileName = "cat.jpg";
        } else if (dog.isSelected()) {
            petName = "Dog";
            fileName = "dog.jpg";
        } else if (rabbit.isSelected()) {
            petName = "Rabbit";
            fileName = "rabbit.jpg";
        } else {
            petName = "Pig";
            fileName = "pig.jpg";
        }

        displayPet(petName, fileName);
        JOptionPane.showMessageDialog(
                this,
                "You selected: " + petName,
                "Pet Selection",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RadioButtonDemo app = new RadioButtonDemo();
            app.setVisible(true);
        });
    }
}
