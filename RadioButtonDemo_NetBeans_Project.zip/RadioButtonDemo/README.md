# RadioButtonDemo — Java Assignment 2

A Java Swing desktop app with five radio buttons (Bird, Cat, Dog, Rabbit and Pig). Selecting a pet changes the displayed picture and opens a message box. Pig is selected when the application starts, matching the assignment illustration.

## Open in NetBeans
1. Choose **File → New Project → Java with Ant → Java Application**. Name it `RadioButtonDemo`.
2. In the project, create a Java class named `RadioButtonDemo` in the default package and replace its contents with `src/RadioButtonDemo.java` from this folder.
3. Copy the `images` folder into the project's **Source Packages** (so it is located at `src/images` beside `RadioButtonDemo.java`). The five image files must keep their names.
4. Run the project. Click each pet; the picture changes and a message box appears.

Alternatively, create a new project folder with this `src` folder as its source root.

## Compile from a terminal (if JDK is installed)
From this folder:
```bash
mkdir -p out
javac -d out src/RadioButtonDemo.java
cp -r src/images out/
java -cp out RadioButtonDemo
```

## GitHub submission
Create a public repository named `Java-RadioButton-Assignment` if your lecturer needs public access. Upload `src/RadioButtonDemo.java`, all five files in `src/images/`, and your screenshots. Commit the files, then submit the repository URL.

The included pet pictures are illustrative images cropped from a generated tutorial graphic. Replace them with clear animal photos of your choice if your lecturer requires photographic images.
